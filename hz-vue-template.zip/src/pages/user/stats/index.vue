<template>
<h1>统计分析</h1>

</template>